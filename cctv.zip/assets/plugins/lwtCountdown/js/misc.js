

$(document).ready(function() {

  "use strict";

      $('#countdown').countDown({
        targetOffset: {
            'day':      0,
            'month':    0,
            'year':     0,
            'hour':     130,
            'min':      0,
            'sec':      3
        }
      });
    })
