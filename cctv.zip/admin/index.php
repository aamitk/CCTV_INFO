<!DOCTYPE html>
<html>
<head>
  <title>Dashbord</title>
  <!-- Header -->
  <?php include("include/head.php"); ?>
  <!-- /.Header -->
</head>
  <!-- Header -->
  <?php include("include/profile.php"); ?>
  <!-- /.Header -->

  <!-- Sidebar -->
  <?php include("include/sidebar.php"); ?>
  <!-- /.Sidebar -->

  <!-- Home -->
  <?php include("include/home.php"); ?>
  <!-- /.Home -->
  
  <!-- Footer -->
  <?php include("include/footer.php"); ?>
  <!-- /.Footer -->

</body>
</html>